<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecb381bfb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SVG; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; class SVG extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __("\123\x56\x47", PR__MDL__SVG); }, Constants::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { Engine::ksyueceqagwomguk(); } }
