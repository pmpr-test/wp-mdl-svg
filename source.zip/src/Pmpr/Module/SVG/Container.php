<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705db86ce9e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SVG; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
