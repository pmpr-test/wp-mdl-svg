<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d004c0d046             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SVG; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
