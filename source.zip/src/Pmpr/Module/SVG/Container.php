<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680d57804afdf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SVG; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
