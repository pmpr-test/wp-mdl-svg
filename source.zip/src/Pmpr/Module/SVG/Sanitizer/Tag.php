<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d004c0d046             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SVG\Sanitizer; use enshrined\svgSanitize\data\AllowedTags; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; class Tag extends AllowedTags { use HelperTrait; public static function getTags() { $kmmywmgcgwceeqii = parent::getTags(); return self::iwgqamekocwaigci()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\x73\x76\x67\x5f\141\x6c\x6c\157\x77\145\x64\137\x74\141\x67\163", $kmmywmgcgwceeqii); } }
