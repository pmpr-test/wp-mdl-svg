<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecb381bfb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SVG\Sanitizer; use enshrined\svgSanitize\data\AllowedTags; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; class Tag extends AllowedTags { use HelperTrait; public static function getTags() { $kmmywmgcgwceeqii = parent::getTags(); return self::iwgqamekocwaigci()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\x73\x76\147\137\x61\154\x6c\157\167\x65\144\x5f\x74\141\147\163", $kmmywmgcgwceeqii); } }
