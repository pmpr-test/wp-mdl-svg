<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705db86ce9e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SVG\Sanitizer; use enshrined\svgSanitize\data\AllowedAttributes; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; class Attribute extends AllowedAttributes { use HelperTrait; public static function getAttributes() { $siquossayskcwkea = parent::getAttributes(); return self::iwgqamekocwaigci()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\163\x76\147\x5f\x61\154\x6c\157\167\x65\144\x5f\141\x74\x74\162\x69\x62\165\x74\x65\163", $siquossayskcwkea); } }
