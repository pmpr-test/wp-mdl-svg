<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d004c0d046             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SVG\Sanitizer; use enshrined\svgSanitize\data\AllowedAttributes; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; class Attribute extends AllowedAttributes { use HelperTrait; public static function getAttributes() { $siquossayskcwkea = parent::getAttributes(); return self::iwgqamekocwaigci()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\163\166\147\137\x61\x6c\x6c\x6f\x77\x65\144\x5f\141\x74\x74\162\x69\142\x75\164\145\x73", $siquossayskcwkea); } }
